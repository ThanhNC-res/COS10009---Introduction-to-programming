require 'rubygems'
require 'gosu'
require './circle'
# HSV values (colour)
# Acknowledgement: This code was produced by a student in a previous semester.

# The screen has layers: Background, middle, top
module ZOrder
  BACKGROUND, MIDDLE, TOP = *0..2
end

class DemoWindow < Gosu::Window
  def initialize
    super(500, 500, false)
    @font = Gosu::Font.new(self, Gosu::default_font_name, 40)
  end

  def draw

    # Bottom Center
    draw_triangle(250, 300, Gosu::Color.from_hsv(358.65, 0.65, 0.804), 210, 200, Gosu::Color.from_hsv(358.65, 0.65, 0.804), 290, 200, Gosu::Color.from_hsv(358.65, 0.65, 0.804), ZOrder::TOP, mode=:default)
    # Top Center
    draw_triangle(250, 165, Gosu::Color.from_hsv(3, 0.5, 0.94), 210, 200, Gosu::Color.from_hsv(3, 0.5, 0.94), 290, 200, Gosu::Color.from_hsv(3, 0.5, 0.94), ZOrder::TOP, mode=:default)
    # Inner Left Top
    draw_triangle(250, 165, Gosu::Color.from_hsv(358.65, 0.65, 0.804), 195, 165, Gosu::Color.from_hsv(358.65, 0.65, 0.804), 210, 200, Gosu::Color.from_hsv(358.65, 0.65, 0.804), ZOrder::TOP, mode=:default)
    # Inner Right Top
    draw_triangle(250, 165, Gosu::Color.from_hsv(0.4, 0.7, 0.78), 305, 165, Gosu::Color.from_hsv(0.4, 0.7, 0.78), 290, 200, Gosu::Color.from_hsv(0.4, 0.7, 0.78), ZOrder::TOP, mode=:default)
    # Bottom Left
    draw_triangle(250, 300, Gosu::Color.from_hsv(359, 0.51, 0.92), 210, 200, Gosu::Color.from_hsv(359, 0.51, 0.92), 150, 200, Gosu::Color.from_hsv(359, 0.51, 0.92), ZOrder::TOP, mode=:default)
    # Bottom Right
    draw_triangle(250, 300, Gosu::Color.from_hsv(359.52, 0.73, 0.67), 290, 200, Gosu::Color.from_hsv(359.52, 0.73, 0.67), 350, 200, Gosu::Color.from_hsv(359.52, 0.73, 0.67), ZOrder::TOP, mode=:default)
    # Outer Left Top
    draw_triangle(210, 200, Gosu::Color.from_hsv(6.1, 0.236, 0.98), 150, 200, Gosu::Color.from_hsv(1.85, 0.255, 1), 195, 165, Gosu::Color.from_hsv(359, 0.247, 1), ZOrder::TOP, mode=:default)
    # Outer Right Top
    draw_triangle(290, 200, Gosu::Color.from_hsv(0, 0.58, 85.9), 350, 200, Gosu::Color.from_hsv(354.96, 0.604, 0.851), 305, 165, Gosu::Color.from_hsv(357.5, 0.566, 0.831), ZOrder::TOP, mode=:default)


    img = Gosu::Image.new(Circle.new(200, 255, 0, 0), false)

    img.draw 50, 50, ZOrder::BACKGROUND


    img2 = Gosu::Image.new(Circle.new(170, 200, 200, 200), false)
    img2.draw 80, 80, ZOrder::MIDDLE


    @font.draw("Ruby", 210, 300, 1, 1.0, 1.0, Gosu::Color::WHITE)
  end
end

DemoWindow.new.show
